<?php

include '../../global/config.php';

//Inialisation du serveur CAS
    include_once('../../libs/CAS/CAS.php');
    phpCAS::client(CAS_VERSION_2_0,SERVEUR_SSO,PORT_SSO,RACINE_SSO);
    phpCAS::setLang(PHPCAS_LANG_FRENCH);
    phpCAS::setNoCasServerValidation();


// Vérification des droits d'accès de la page
if ((isset($_SESSION['login'])) && (!empty($_SESSION['login']))) {

	// On affiche la page d'erreur comme quoi l'utilisateur est déjà connecté   
	include '../../vues_globales/erreur_deja_connecte.php';
	
} else {
	phpCAS::forceAuthentication();

	//on stocke le login dans la variale de session correspondante
	$_SESSION['login'] = phpCAS::getUser();

/*
	//Traitement des nouveaux utilisateurs
	include '../../modeles/utilisateur.php';
	$utilisateur = mysql_fetch_array(detail_utilisateur($_SESSION['login']), MYSQL_BOTH);
	$_SESSION['administrateur'] = $utilisateur['administrateur'];
	$_SESSION['nom'] = $utilisateur['nom'];
	$_SESSION['prenom'] = $utilisateur['prenom'];
	if ( $utilisateur[0] == '')
	{
		$message = "Ceci est votre première visite. Prenez quelques minutes pour <a href='index.php?module=utilisateur&action=modifier_profil'>compléter votre profil</a><br>!";
		ajouter_utilisateur($_SESSION['login'], $_SESSION['login'].'@etu.utc.fr');
	}
	else
	{
		$message = "Vous êtes déjà enregistré.<br>";
		if (empty($_SESSION['nom']) OR empty($_SESSION['prenom'])) {
			$message.="Votre profil n'est pas complet. <a href='index.php?module=utilisateur&action=modifier_profil'>Cliquer ici pour le completer maintenant.</a><br>";
		}
	}
*/
	//Affichage de la confirmation de connexion
	include 'vue/connexion_ok.php';
}
?>


