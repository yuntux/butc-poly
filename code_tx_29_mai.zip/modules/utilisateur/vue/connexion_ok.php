<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="refresh" content="5; url=../../index.php" />
<title>Connexion réussie</title>
<meta name="robots" content="noindex,follow" />
</head>


<h1><p>Bienvenue<br />
Vous êtes maintenant connecté !</p></h1>

<?php echo $message; ?>

Vous allez être redirigé vers la <a href="../../index.php">page d'accueil</a>.

</html>
