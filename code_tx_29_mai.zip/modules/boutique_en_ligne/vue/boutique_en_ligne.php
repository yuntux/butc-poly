<div class="groupe" style="margin-top:10px;width:97.5%;" id="panier">
<form name="modif_panier" action="index.php?module=boutique_en_ligne&action=boutique_en_ligne" method="post">
<TABLE id="pannier">
	<CAPTION>Pannier</CAPTION>
	<THEAD>
		<TR><TH>Code</TH> <TH>Quantité</TH> <TH>Prix Unitaire</TH> <TH>Montant</TH> <TH>Action</TH></TR>
	</THEAD>
	<TBODY>
<?php
	if (creationPanier())
	{
	   $nbArticles=compterArticles();
	   if ($nbArticles <= 0)
	   echo '<tr><td colspan="5">Votre panier est vide </ td></tr>';
	   else
	   {
	      for ($i=0 ;$i < $nbArticles ; $i++)
	      {
	         echo "<tr>";
	         echo "<td>".htmlspecialchars($_SESSION['panier']['libelleProduit'][$i])."</td>";
	         echo "<td>".htmlspecialchars($_SESSION['panier']['qteProduit'][$i])."</td>";
	         echo "<td>".htmlspecialchars($_SESSION['panier']['prixProduit'][$i])."</td>";
$montant = $_SESSION['panier']['prixProduit'][$i]*$_SESSION['panier']['qteProduit'][$i];
	         echo "<td>".htmlspecialchars($montant)."</td>";
	         echo "<td><a href=\"".htmlspecialchars("index.php?module=boutique_en_ligne&action=boutique_en_ligne&supprimer_poly=".rawurlencode($_SESSION['panier']['libelleProduit'][$i]))."\">Supprimer</a></td>";
	         echo "</tr>";
	      }
	   }
	}
?>
	<TBODY>
	<TFOOT>
		<TR><td colspan="5">
	    <?php echo "Total : ".MontantGlobal();?>
		</td></TR>
	</TFOOT>
</TABLE>

<input type="submit" name="payer_panier" value="PAYER" class="btn_valider">
</form>
</div>

<br>

<div class="groupe" style="margin-top:10px;width:97.5%;" id="liste_poly">
<form name="ajouter_poly" action="index.php?module=boutique_en_ligne&action=boutique_en_ligne" method="post">
	<TABLE id="liste_poly">		
		<CAPTION>Liste des poly disponibles</CAPTION>
		<THEAD>
			<TR><TH></TH> <TH>CS</TH> <TH>TM</TH> <TH>TSH</TH></TR>
		</THEAD>

		<TBODY>
			<TR>
				<TH>TC</TH>
				<TD><input type="button" name="nom" value="CS1_COURS"></TD>
				<TD><input type="button" name="ajouter_poly" value="TM1_COURS" onclick="ajouterArticlePannier(this.name);"></td>
				<TD rowspan="7">TSH1</TD>
			</TR>

			<TR>
				<TH>GB</TH>
				<TD>
	<?php
		while($poly = $liste_poly_gb_cs->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>
				<TD>
	<?php
		while($poly = $liste_poly_gb_tm->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>

			</TR>

			<TR>
				<TH>GI</TH>
				<TD>
	<?php
		while($poly = $liste_poly_gi_cs->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>
				<TD>
	<?php
		while($poly = $liste_poly_gi_tm->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>

			</TR>

			<TR>
				<TH>GM</TH>
				<TD>
	<?php
		while($poly = $liste_poly_gm_cs->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>
				<TD>
	<?php
		while($poly = $liste_poly_gm_tm->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>

			</TR>

			<TR>
				<TH>GP</TH>
				<TD>
	<?php
		while($poly = $liste_poly_gp_cs->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>
				<TD>
	<?php
		while($poly = $liste_poly_gp_tm->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>

			</TR>

			<TR>
				<TH>GSM</TH>
				<TD>
	<?php
		while($poly = $liste_poly_gsm_cs->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>
				<TD>
	<?php
		while($poly = $liste_poly_gsm_tm->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>

			</TR>

			<TR>
				<TH>GSU</TH>
				<TD>
	<?php
		while($poly = $liste_poly_gsu_cs->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>
				<TD>
	<?php
		while($poly = $liste_poly_gsu_tm->fetch())
		{
			echo '<input type="submit" name="ajouter_poly" value="'.$poly->code_barre.'">';
		}
	?>
				</TD>

			</TR>
		<TBODY>
	</TABLE>
</FORM>
</div>
