<br><br><br>
<center>
<p>Aurélien DUMAINE (P12) - Code sous licence libre AfferoGPL disponible sur <a href="truc">ce dépot Git</a>.</p>
</center>

</body></html>
