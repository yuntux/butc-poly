<?php
	//AFFICHAGE DES ERREURS => OFF EN PRODUCTION
	ini_set('display_errors', 1); 
	error_reporting(E_ALL);

	session_start();
	$_SESSION['login']='usertest';

	if(isset($_GET['profil_demo_acheteur']))
		$_SESSION['acheteur'] = 1;

	if(isset($_GET['profil_demo_admin']))
		$_SESSION['administrateur'] = 1;

	if(isset($_GET['profil_demo_vendeur']))
		$_SESSION['vendeur'] = 1;

	echo 'ENVIRONNEMENT DE DEMO';

	echo '<a href="index.php?profil_demo_acheteur=1" >Profil acheteur</a>        ';
	echo '<a href="index.php?profil_demo_vendeur=1">Profil vendeur</a>       ';
	echo '<a href="index.php?profil_demo_admin=1">Profil admin</a>';


?>
