<div id="content">
<div class="post">
<h2 class="title">Perdu... dommage</h2>
<div class="entry">

<p>Tu es venu, tu as joué, tu as perdu. Essaye encore.</p>

</div>
</div>
<div style="clear: both;">&nbsp;</div>
</div>

<!-- end #content -->
