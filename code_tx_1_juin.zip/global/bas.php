<br><br><br>
<center>
<p>Aurélien DUMAINE (P12) - Code sous licence libre <a href="http://www.gnu.org/licenses/agpl-3.0.html">AfferoGPL</a> disponible sur <a href="truc">ce dépot Git</a>.</p>
</center>

</body></html>
