<div id="content">
<div class="post">

<h2 class="title">Bienvenue sur la boutique en ligne de la BU</h2>
<p class="meta">Acheter et payer ses poly en ligne.</p>
	<div class="entry">
		<p> 
1) les etu choississent et payent leurs polys en ligne
<br>
2) ils posent leur carte sur le lecteur de la BUTC
<br>
3) le vendeur leur donne les polys, le bon d'enlècvement est pré-rempli selon les commandes et le stock disponible
<br>
*) le vendeur peut vendre des polys sans pré-commande en cas d'oubli
		</p>
	</div>
</div>
<div style="clear: both;">&nbsp;</div>
		</div>

