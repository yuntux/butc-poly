<?php

if ((!isset($_SESSION['login'])) || (empty($_SESSION['login'])))  {

    include CHEMIN_VUE_GLOBALE.'erreur_non_connecte.php';

} else {
	
    include_once CHEMIN_MODELE.'boutique_en_ligne.php';
	include(CHEMIN_LIB.'fonctions-panier.php');

	if (isset($_POST['payer_panier'])) {
		//on enregistre la commande en base
		//on génère le fichier texte de paiement
		//on l'envoie au cgi en ligne de commande
	}

}
?>
