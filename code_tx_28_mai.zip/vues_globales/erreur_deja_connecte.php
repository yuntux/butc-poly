<div id="content">
<div class="post">
<h2 class="title">Accès inutile</h2>
<div class="entry">

<p>Inutile d'accéder à cette page si vous êtes connecté.</p>

</div>
</div>
<div style="clear: both;">&nbsp;</div>
</div>

<!-- end #content -->


