<?php

// Identifiants pour la base de données. Nécessaires a PDO2.
define('SQL_HOST', 'localhost');
define('SQL_USERNAME', 'demeter_poly');
define('SQL_PASSWORD', 'demeter_poly');
define('SQL_DATABASE', 'demeter_poly');

//KEY GOOGLE MAISON
//define('API_KEY_GOOGLE', 'ABQIAAAAh3kueG2rku3MisjgIw7QXRSnvB70HEo7IJW0pDJx21Imb0jOVRS-E5Lr6vAKVsBlipZ-xYf1DW0yFA');
//KEY GOOGLE http://172.25.25.246
//define('API_KEY_GOOGLE', 'ABQIAAAAh3kueG2rku3MisjgIw7QXRTBfS3hqKdMz-j_A351rHx2nl_2HhT4OLvdDMeoF16gf2Ik26-cKJ5nuA');
//KEY GOOGLE http://wwwassos.utc.fr
define('API_KEY_GOOGLE', 'ABQIAAAAh3kueG2rku3MisjgIw7QXRTGFbb6NKMBv3xYMyYpogfYxUPPyRS-0QFwgm5JcIM1uTf8g_Ai1XYs1Q');

// Chemins à utiliser pour accéder aux vues/modeles/librairies
$module = empty($module) ? !empty($_GET['module']) ? $_GET['module'] : 'index' : $module;
define('CHEMIN_VUE',    'modules/'.$module.'/vue/');
define('CHEMIN_MODELE', 'modules/'.$module.'/modele/');
define('CHEMIN_CONTROLEUR', 'modules/'.$module.'/controleur/');
define('CHEMIN_VUE_GLOBALE', 'vues_globales/');
define('CHEMIN_LIB',    'libs/');

//Paramètres du serveur CAS
define('SERVEUR_SSO', 'cas.utc.fr');
define('PORT_SSO', 443);
define('RACINE_SSO', 'cas');
?>
