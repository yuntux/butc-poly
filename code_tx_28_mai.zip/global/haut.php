<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : EarthlingTwo  
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20090918
-->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Demeter Polys</title>
	<meta name="author" content="Aurélien DUMAINE">
	<meta name="description" content="TX P12 : paiement en ligne des polys à l'UTC">
	<meta name="keywords" content="UTC, TX">
	<meta name="language" content="fr">
	<meta name="revist-after" content="30 days">
	<meta name="robots" content="ALL">
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="style/menu.css" type="text/css">
    <link rel="stylesheet" href="style/tableaux.css" type="text/css">

    <link rel="stylesheet" href="style/demeter_commun.css" type="text/css">
    <link rel="stylesheet" href="rajout.css" type="text/css">
	<link rel="shortcut icon" type="image/x-icon" href="https://ent.utc.fr/uPortal/favicon.ico" /> 

    <script type="text/javascript" src="https://demeter.utc.fr/pls/portal30/docs/PAGE/PORTLETREPOSITORY/OTHER_PROVIDERS/PORTAIL_SIGAM/JS/COMMUN.JS"></script>      
    <script type="text/javascript">
<!-- javascript -->
	</script>
</head>
<body>

<ul id="menu">
	<li><a href="http://www.red-team-design.com/">Home</a></li>
	<li>
		<a href="#">Boutique en ligne</a>
		<ul>
			<li><a href="index.php?module=boutique_en_ligne&action=boutique_en_ligne">Acheter des poly</a></li>
			<li><a href="/index.php?module=boutique_en_ligne&action=synthese">Synthèse achats</a></li>
			<li><a href="/index.php?module=boutique_en_ligne&action=liste_commandes">Commandes</a></li>
			<li><a href="/index.php?module=boutique_en_ligne&action=liste_paiements">Paiement</a></li>
			<li><a href="/index.php?module=boutique_en_ligne&action=liste_retraits">Retraits</a></li>
		</ul>	
		<a href="#">Categories</a>
		<ul>
			<li>
				<a href="#">Boutique en ligne</a>
				<ul>
					<li><a href="index.php?module=boutique_en_ligne&action=boutique_en_ligne">Acheter des poly</a></li>
					<li><a href="/index.php?module=boutique_en_ligne&action=synthese">Synthèse achats</a></li>
					<li><a href="/index.php?module=boutique_en_ligne&action=liste_commandes">Commandes</a></li>
					<li><a href="/index.php?module=boutique_en_ligne&action=liste_paiements">Paiement</a></li>
					<li><a href="/index.php?module=boutique_en_ligne&action=liste_retraits">Retraits</a></li>
				</ul>				
			</li>
			<li>
				<a href="#">Graphic design</a>
				<ul>
					<li><a href="#">Item 21</a></li>
					<li><a href="#">Item 22</a></li>
					<li><a href="#">Item 23</a></li>
					<li><a href="#">Item 24</a></li>
				</ul>				
			</li>
			<li>
				<a href="#">Development tools</a>
				<ul>
					<li><a href="#">Item 31</a></li>
					<li><a href="#">Item 32</a></li>
					<li><a href="#">Item 33</a></li>
					<li><a href="#">Item 34</a></li>
				</ul>				
			</li>
			<li>
				<a href="#">Web design</a>				
				<ul>
					<li><a href="#">Item 41</a></li>
					<li><a href="#">Item 42</a></li>
					<li><a href="#">Item 43</a></li>
					<li><a href="#">Item 44</a></li>
				</ul>	
			</li>
		</ul>
	</li>
	<li>
		<a href="#">Work</a>
		<ul>
			<li>
				<a href="#">Work 1</a>
				<ul>
					<li>
						<a href="#">Work 11</a>		
						<ul>
							<li>
								<a href="#">Work 111</a>						
							</li>
							<li>
								<a href="#">Work 112</a>
							</li>
							<li>
								<a href="#">Work 113</a>
							</li>
						</ul>							
					</li>
					<li>
						<a href="#">Work 12</a>
						<ul>
							<li>
								<a href="#">Work 121</a>						
							</li>
							<li>
								<a href="#">Work 122</a>
							</li>
							<li>
								<a href="#">Work 123</a>
							</li>
						</ul>							
					</li>
					<li>
						<a href="#">Work 13</a>
						<ul>
							<li>
								<a href="#">Work 131</a>						
							</li>
							<li>
								<a href="#">Work 132</a>
							</li>
							<li>
								<a href="#">Work 133</a>
							</li>
						</ul>							
					</li>
				</ul>					
			</li>
			<li>
				<a href="#">Work 2</a>
				<ul>
					<li>
						<a href="#">Work 21</a>
						<ul>
							<li>
								<a href="#">Work 211</a>						
							</li>
							<li>
								<a href="#">Work 212</a>
							</li>
							<li>
								<a href="#">Work 213</a>
							</li>
						</ul>							
					</li>
					<li>
						<a href="#">Work 22</a>
						<ul>
							<li>
								<a href="#">Work 221</a>						
							</li>
							<li>
								<a href="#">Work 222</a>
							</li>
							<li>
								<a href="#">Work 223</a>
							</li>
						</ul>							
					</li>
					<li>
						<a href="#">Work 23</a>
						<ul>
							<li>
								<a href="#">Work 231</a>						
							</li>
							<li>
								<a href="#">Work 232</a>
							</li>
							<li>
								<a href="#">Work 233</a>
							</li>
						</ul>							
					</li>
				</ul>					
			</li>
			<li>
				<a href="#">Work 3</a>
				<ul>
					<li>
						<a href="#">Work 31</a>
						<ul>
							<li>
								<a href="#">Work 311</a>						
							</li>
							<li>
								<a href="#">Work 312</a>
							</li>
							<li>
								<a href="#">Work 313</a>
							</li>
						</ul>							
					</li>
					<li>
						<a href="#">Work 32</a>
						<ul>
							<li>
								<a href="#">Work 321</a>						
							</li>
							<li>
								<a href="#">Work 322</a>
							</li>
							<li>
								<a href="#">Work 323</a>
							</li>
						</ul>							
					</li>
					<li>
						<a href="#">Work 33</a>
						<ul>
							<li>
								<a href="#">Work 331</a>						
							</li>
							<li>
								<a href="#">Work 332</a>
							</li>
							<li>
								<a href="#">Work 333</a>
							</li>
						</ul>							
					</li>
				</ul>					
			</li>
		</ul>		
	</li>
	<li>
		<a href="#">About</a>	
	</li>
	<li>
		<a href="#">Contact</a>	
	</li>
</ul>

<br>
