<div id="content">
<div class="post">

<h2 class="title">Bienvenue sur la boutique en ligne de la BU</h2>
<p class="meta">Gérer son traffic aérien en trois clics !</p>
	<div class="entry">
		<p> 
test
		</p>
	</div>
</div>
<div style="clear: both;">&nbsp;</div>
		</div>

