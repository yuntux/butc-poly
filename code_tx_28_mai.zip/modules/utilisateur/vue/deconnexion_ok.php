<div id="content">
<div class="post">
<h2 class="title">Confirmation de déconnexion></h2>
<div class="entry">
<p>Vous êtes maintenant déconnecté.<br />
<a href="index.php">Revenir à la page d'accueil</a></p>
</div
</div>
<div style="clear: both;">&nbsp;</div>
</div>
<!-- end #content -->
