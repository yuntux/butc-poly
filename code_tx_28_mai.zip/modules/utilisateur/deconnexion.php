<?php

include '../../global/config.php';

//Inialisation du serveur CAS
	include_once(CHEMIN_LIB.'CAS/CAS.php');
	phpCAS::client(CAS_VERSION_2_0,SERVEUR_SSO,PORT_SSO,RACINE_SSO);
//	phpCAS::setLang(PHPCAS_LANG_FRENCH);
	phpCAS::setNoCasServerValidation();
	phpCAS::logout();

$_SESSION['login']="";

//Affichage de la confirmation de connexion
include 'vue/deconnexion_ok.php';
?>
