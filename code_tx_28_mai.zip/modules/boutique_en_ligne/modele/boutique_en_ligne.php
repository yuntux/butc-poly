<?php
function lister_poly($branche="", $type=""){
	global $connexion;
	if ($branche != "") {
	$resultats=$connexion->query("SELECT * FROM uv, poly, rel_uv_branche WHERE (poly.id_uv=uv.id AND rel_uv_branche.uv=uv.id AND rel_uv_branche.branche=".$connexion->quote($branche, PDO::PARAM_STR)."AND uv.type LIKE ".$connexion->quote($type, PDO::PARAM_STR).")") or die(print_r($connexion->errorInfo()));
	} else {
	$resultats=$connexion->query("SELECT * FROM uv, poly, rel_uv_branche WHERE (poly.id_uv=uv.id AND rel_uv_branche.uv=uv.id AND branche='GI')") or die(print_r($connexion->errorInfo()));
	}
	$resultats->setFetchMode(PDO::FETCH_OBJ);
	return $resultats;
}

function detailler_poly($code){
	global $connexion;
	$resultats=$connexion->query("SELECT * FROM poly WHERE code_barre=".$connexion->quote($code, PDO::PARAM_STR)) or die(print_r($connexion->errorInfo()));
	$resultats->setFetchMode(PDO::FETCH_OBJ);
	return $resultats;
}
?>
